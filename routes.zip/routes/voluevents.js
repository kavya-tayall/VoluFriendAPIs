const express = require('express');
const router = express.Router();
const db = require('../config/firebase');

// Helper function to fetch organization data
const getOrgData = async (orgId) => {
  const orgRef = db.ref(`organizations/${orgId}`);
  const orgSnapshot = await orgRef.once('value');
  return orgSnapshot.val();
};

// Helper function to fetch org_user data
const getOrgUserData = async (orgUserId) => {
  const orgUserRef = db.ref(`org_users/${orgUserId}`);
  const orgUserSnapshot = await orgUserRef.once('value');
  return orgUserSnapshot.val();
};

// Helper function to check if user is an admin for a given organization
const isAdminForOrg = async (orgUserId, orgId) => {
  const orgUserData = await getOrgUserData(orgUserId);
  return orgUserData && orgUserData.organization_id === orgId && orgUserData.user_role_in_Org === 'Admin';
};

// Middleware to validate org_user_id and org_id
const validateOrgUserAndOrg = async (req, res, next) => {
  const { org_user_id, org_id } = req.body;

  try {
    // Check if org_id is valid
    const orgData = await getOrgData(org_id);
    if (!orgData) {
      return res.status(400).json({ error: 'Invalid organization ID.' });
    }

    // Check if org_user_id exists
    const orgUserData = await getOrgUserData(org_user_id);
    if (!orgUserData) {
      return res.status(404).json({ error: 'Organization user not found.' });
    }

    // Check if the user is an admin for the given org_id
    const isAdmin = await isAdminForOrg(org_user_id, org_id);
    if (!isAdmin) {
      return res.status(403).json({ error: 'User does not have admin role for this organization.' });
    }

    // Proceed to next middleware or route handler
    next();
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// CRUD operations for Events

// GET all events with optional filters for org_user_id and org_id
router.get('/', async (req, res) => {
  try {
    const { org_user_id, org_id } = req.body; // Using query parameters for filtering

    let eventsRef = db.ref('events');

    // Apply filters if provided
    if (org_user_id || org_id) {
      let filterQuery = eventsRef;

      if (org_user_id) {
        filterQuery = filterQuery.orderByChild('created_by_org_user').equalTo(org_user_id);
      }

      if (org_id) {
        filterQuery = filterQuery.orderByChild('org_id').equalTo(org_id);
      }

      // Execute the query
      const snapshot = await filterQuery.once('value');
      res.json(snapshot.val() || {});
    } else {
      // No filters, return all events
      const snapshot = await eventsRef.once('value');
      res.json(snapshot.val() || {});
    }
  } catch (error) {
    console.error('Error fetching events:', error.message);
    res.status(500).json({ error: 'Internal Server Error. Could not retrieve events.' });
  }
});

// GET all events with their corresponding shifts, with optional filters
router.get('/events-with-shifts', async (req, res) => {
  try {
    const { org_user_id, org_id } = req.body;

    let eventsRef = db.ref('events');

    // Apply filters if provided
    if (org_user_id || org_id) {
      let filterQuery = eventsRef;

      if (org_user_id) {
        filterQuery = filterQuery.orderByChild('created_by_org_user').equalTo(org_user_id);
      }

      if (org_id) {
        filterQuery = filterQuery.orderByChild('org_id').equalTo(org_id);
      }

      // Execute the query
      const eventsSnapshot = await filterQuery.once('value');
      const eventsData = eventsSnapshot.val() || {};

      const eventIds = Object.keys(eventsData);
      const shiftsPromises = eventIds.map(eventId => 
        db.ref('shifts').orderByChild('event_id').equalTo(eventId).once('value')
      );

      const shiftsSnapshots = await Promise.all(shiftsPromises);
      const shiftsData = shiftsSnapshots.map(snapshot => snapshot.val() || {});

      const shiftsMap = {};
      shiftsData.forEach((shiftData, index) => {
        const eventId = eventIds[index];
        shiftsMap[eventId] = shiftData;
      });

      for (const eventId in eventsData) {
        eventsData[eventId].shifts = shiftsMap[eventId] || {};
      }

      res.json(eventsData);
    } else {
      // No filters, return all events with shifts
      const eventsSnapshot = await eventsRef.once('value');
      const eventsData = eventsSnapshot.val() || {};

      const eventIds = Object.keys(eventsData);
      const shiftsPromises = eventIds.map(eventId => 
        db.ref('shifts').orderByChild('event_id').equalTo(eventId).once('value')
      );

      const shiftsSnapshots = await Promise.all(shiftsPromises);
      const shiftsData = shiftsSnapshots.map(snapshot => snapshot.val() || {});

      const shiftsMap = {};
      shiftsData.forEach((shiftData, index) => {
        const eventId = eventIds[index];
        shiftsMap[eventId] = shiftData;
      });

      for (const eventId in eventsData) {
        eventsData[eventId].shifts = shiftsMap[eventId] || {};
      }

      res.json(eventsData);
    }
  } catch (error) {
    console.error('Error fetching events with shifts:', error.message);
    res.status(500).json({ error: 'Internal Server Error. Could not retrieve events with shifts.' });
  }
});

// Apply validation middleware to POST and PUT routes
router.post('/', validateOrgUserAndOrg, async (req, res) => {
    try {
      const eventsRef = db.ref('events');
      const newEventRef = eventsRef.push(); // Use Firebase ID generation
      const eventData = req.body;
  
      // Remove shifts from event data if present
      const { shifts, ...eventWithoutShifts } = eventData;
      eventWithoutShifts.created_at = new Date().toISOString();
      eventWithoutShifts.updated_at = new Date().toISOString();
  
      // Post the event data
      await newEventRef.set(eventWithoutShifts);
  
      // Handle shifts if provided
      if (shifts) {
        const shiftPromises = Object.entries(shifts).map(async ([shiftId, shiftData]) => {
          shiftData.event_id = newEventRef.key; // Add event ID to shifts
          const shiftRef = db.ref(`shifts/${shiftId}`);
          await shiftRef.set(shiftData);
          return { id: shiftId, ...shiftData };
        });
  
        const shiftResults = await Promise.all(shiftPromises);
        res.status(201).json({
          id: newEventRef.key,
          shifts: shiftResults,
          originalBody: { ...eventWithoutShifts, id: newEventRef.key }
        });
      } else {
        res.status(201).json({
          id: newEventRef.key,
          originalBody: { ...eventWithoutShifts, id: newEventRef.key }
        });
      }
    } catch (error) {
      console.error('Error creating event:', error.message);
      res.status(500).json({ error: 'Internal Server Error. Could not create the event.' });
    }
  });
  
  router.put('/:event_id', validateOrgUserAndOrg, async (req, res) => {
    try {
      const eventRef = db.ref(`events/${req.params.event_id}`);
      const updateData = req.body;
  
      // Check if the event exists before updating
      const snapshot = await eventRef.once('value');
      if (!snapshot.exists()) {
        return res.status(404).json({ error: 'Event not found.' });
      }
  
      // Remove shifts from update data if present
      const { shifts, ...updateWithoutShifts } = updateData;
      await eventRef.update(updateWithoutShifts);
  
      // Handle shifts if provided
      if (shifts) {
        const shiftPromises = Object.entries(shifts).map(async ([shiftId, shiftData]) => {
          shiftData.event_id = req.params.event_id; // Add event ID to shifts
          const shiftRef = db.ref(`shifts/${shiftId}`);
          await shiftRef.update(shiftData);
          return { id: shiftId, ...shiftData };
        });
  
        const shiftResults = await Promise.all(shiftPromises);
        res.json({
          message: 'Event updated successfully',
          shifts: shiftResults,
          originalBody: { ...updateWithoutShifts, id: req.params.event_id }
        });
      } else {
        res.json({
          message: 'Event updated successfully',
          originalBody: { ...updateWithoutShifts, id: req.params.event_id }
        });
      }
    } catch (error) {
      console.error('Error updating event:', error.message);
      res.status(500).json({ error: 'Internal Server Error. Could not update the event.' });
    }
  });
  
// DELETE an event
router.delete('/:event_id', async (req, res) => {
  try {
    const eventId = req.params.event_id;

    // First, delete all shifts related to the event
    const shiftsRef = db.ref('shifts');
    const shiftsSnapshot = await shiftsRef.orderByChild('event_id').equalTo(eventId).once('value');
    const shiftsData = shiftsSnapshot.val();

    if (shiftsData) {
      const shiftPromises = Object.keys(shiftsData).map(shiftId =>
        shiftsRef.child(shiftId).remove()
      );
      await Promise.all(shiftPromises);
    }

    // Then, delete the event
    const eventRef = db.ref(`events/${eventId}`);
    const eventSnapshot = await eventRef.once('value');
    if (!eventSnapshot.exists()) {
      return res.status(404).json({ error: 'Event not found.' });
    }

    await eventRef.remove();
    res.json({ message: 'Event and associated shifts deleted successfully' });
  } catch (error) {
    console.error('Error deleting event:', error.message);
    res.status(500).json({ error: 'Internal Server Error. Could not delete the event.' });
  }
});

// GET all shifts for a specific event ID
router.get('/:event_id/shifts', async (req, res) => {
  try {
    const eventId = req.params.event_id;
    const shiftsRef = db.ref('shifts');
    const shiftsSnapshot = await shiftsRef.orderByChild('event_id').equalTo(eventId).once('value');
    const shiftsData = shiftsSnapshot.val() || {};
    res.json(shiftsData);
  } catch (error) {
    console.error('Error fetching shifts for event:', error.message);
    res.status(500).json({ error: 'Internal Server Error. Could not retrieve shifts for the event.' });
  }
});

// POST a new shift
router.post('/shifts', async (req, res) => {
  try {
    const shiftsRef = db.ref('shifts');
    const newShiftRef = shiftsRef.push(); // Use Firebase ID generation
    const shiftData = req.body;
    shiftData.created_at = new Date().toISOString();
    shiftData.updated_at = new Date().toISOString();
    await newShiftRef.set(shiftData);
    res.status(201).json({ id: newShiftRef.key });
  } catch (error) {
    console.error('Error creating shift:', error.message);
    res.status(500).json({ error: 'Internal Server Error. Could not create the shift.' });
  }
});

// PUT to update a shift
router.put('/shifts/:shift_id', async (req, res) => {
  try {
    const shiftRef = db.ref(`shifts/${req.params.shift_id}`);
    const updateData = req.body;

    // Check if the shift exists before updating
    const snapshot = await shiftRef.once('value');
    if (!snapshot.exists()) {
      return res.status(404).json({ error: 'Shift not found.' });
    }

    await shiftRef.update(updateData);
    res.json({ message: 'Shift updated successfully' });
  } catch (error) {
    console.error('Error updating shift:', error.message);
    res.status(500).json({ error: 'Internal Server Error. Could not update the shift.' });
  }
});

// DELETE a shift
router.delete('/shifts/:shift_id', async (req, res) => {
  try {
    const shiftRef = db.ref(`shifts/${req.params.shift_id}`);
    const snapshot = await shiftRef.once('value');

    if (!snapshot.exists()) {
      return res.status(404).json({ error: 'Shift not found.' });
    }

    await shiftRef.remove();
    res.json({ message: 'Shift deleted successfully' });
  } catch (error) {
    console.error('Error deleting shift:', error.message);
    res.status(500).json({ error: 'Internal Server Error. Could not delete the shift.' });
  }
});

module.exports = router;
